#include <iostream>
#include "Usuario.h"

Usuario::Usuario()
{
}

Usuario::~Usuario()
{
}
